"""
API Integration Tests for FastAPI Backend
Tests all endpoints using FastAPI's in-process TestClient.
"""

import os
import sys

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)


def test_endpoints():
    print("=" * 60)
    print("RUNNING FASTAPI ENDPOINT TESTS")
    print("=" * 60)

    # 1. Root
    res = client.get("/")
    assert res.status_code == 200
    print("[PASS] GET / ->", res.json())

    # 2. Health
    res = client.get("/api/v1/health")
    assert res.status_code == 200
    print("[PASS] GET /api/v1/health ->", res.json())

    # 3. KPIs
    res = client.get("/api/v1/kpis")
    assert res.status_code == 200
    kpis = res.json()
    print("[PASS] GET /api/v1/kpis -> Total Customers:", kpis["total_customers"], "| At-Risk Revenue: $" + str(kpis["at_risk_revenue"]))

    # 4. List Customers (filtered)
    res = client.get("/api/v1/customers?segment=At-Risk%20High-Spenders&limit=3")
    assert res.status_code == 200
    custs = res.json()
    print(f"[PASS] GET /api/v1/customers -> Total matching: {custs['total_records']}, Returned: {len(custs['customers'])}")

    # 5. Customer 360 Detail
    res = client.get("/api/v1/customers/5524")
    assert res.status_code == 200
    cust = res.json()
    print(f"[PASS] GET /api/v1/customers/5524 -> {cust['Customer_Name']} | Churn: {cust['Churn_Probability']*100:.1f}% | Spend: ${cust['Monetary_Total_Spend']}")

    # 6. Generate Retention Campaign via LangGraph
    print("\nTriggering POST /api/v1/campaigns/generate for Customer #5524...")
    res = client.post("/api/v1/campaigns/generate", json={"customer_id": 5524, "model_name": "qwen2.5:3b"})
    assert res.status_code == 200
    campaign = res.json()
    print("[PASS] POST /api/v1/campaigns/generate -> Campaign ID:", campaign.get("campaign_id"))
    print("  Subject:", campaign.get("email_subject"))
    print("  Incentive:", campaign.get("recommended_incentive"))
    print("  Status:", campaign.get("quality_status"))

    # 7. List Campaigns
    res = client.get("/api/v1/campaigns")
    assert res.status_code == 200
    c_list = res.json()
    print(f"[PASS] GET /api/v1/campaigns -> Logged campaigns count: {len(c_list)}")

    print("\nALL API ENDPOINTS TESTED AND VERIFIED SUCCESSFULLY!")


if __name__ == "__main__":
    test_endpoints()

