"""
Data Ingestion and Preprocessing Pipeline
Customer Segmentation & Retention System
"""

import os
from datetime import datetime
import numpy as np
import pandas as pd


def load_raw_data(filepath: str) -> pd.DataFrame:
    """Load raw marketing campaign dataset from tab-separated CSV file."""
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Dataset not found at: {filepath}")
    
    print(f"Loading raw data from: {filepath}")
    df = pd.read_csv(filepath, sep="\t")
    print(f"Raw dataset loaded successfully with shape: {df.shape}")
    return df


def preprocess_customer_data(df: pd.DataFrame, reference_year: int = 2024) -> pd.DataFrame:
    """Clean, impute missing values, filter outliers, and engineer RFM and behavioral features."""
    df_clean = df.copy()

    # 1. Handle Missing Values
    # Impute missing Income using median income grouped by Education level
    income_median_by_edu = df_clean.groupby("Education")["Income"].transform("median")
    df_clean["Income"] = df_clean["Income"].fillna(income_median_by_edu)

    # 2. Filter Extreme Outliers
    # Customers born before 1930 (age > 94) or income > $200,000 are statistical anomalies/bad inputs
    df_clean = df_clean[df_clean["Year_Birth"] >= 1930]
    df_clean = df_clean[df_clean["Income"] < 200000]

    # 3. Clean Categorical Variables
    # Standardize Marital_Status into clear business cohorts
    marital_mapping = {
        "Married": "Partnered",
        "Together": "Partnered",
        "Single": "Single",
        "Divorced": "Single",
        "Widow": "Single",
        "Alone": "Single",
        "Absurd": "Single",
        "YOLO": "Single",
    }
    df_clean["Marital_Status_Clean"] = df_clean["Marital_Status"].map(marital_mapping).fillna("Single")

    # Standardize Education
    education_mapping = {
        "Basic": "Undergraduate",
        "2n Cycle": "Master",
        "Graduation": "Graduate",
        "Master": "Master",
        "PhD": "Postgraduate",
    }
    df_clean["Education_Clean"] = df_clean["Education"].map(education_mapping).fillna("Graduate")

    # 4. Feature Engineering - Demographics
    df_clean["Age"] = reference_year - df_clean["Year_Birth"]
    df_clean["Total_Children"] = df_clean["Kidhome"] + df_clean["Teenhome"]
    df_clean["Has_Children"] = (df_clean["Total_Children"] > 0).astype(int)
    
    # Estimate household size
    is_partnered = (df_clean["Marital_Status_Clean"] == "Partnered").astype(int)
    df_clean["Family_Size"] = 1 + is_partnered + df_clean["Total_Children"]

    # 5. Customer Tenure (Enrollment date)
    df_clean["Dt_Customer"] = pd.to_datetime(df_clean["Dt_Customer"], format="%d-%m-%Y")
    max_date = df_clean["Dt_Customer"].max()
    df_clean["Customer_Tenure_Days"] = (max_date - df_clean["Dt_Customer"]).dt.days

    # 6. RFM Metrics (Recency, Frequency, Monetary)
    # Recency: Already present in dataset as days since last purchase (0 - 99)
    # Monetary: Sum of all product category expenditures
    spend_cols = [
        "MntWines",
        "MntFruits",
        "MntMeatProducts",
        "MntFishProducts",
        "MntSweetProducts",
        "MntGoldProds",
    ]
    df_clean["Monetary_Total_Spend"] = df_clean[spend_cols].sum(axis=1)

    # Frequency: Total number of purchases across all channels
    purchase_cols = [
        "NumWebPurchases",
        "NumCatalogPurchases",
        "NumStorePurchases",
        "NumDealsPurchases",
    ]
    df_clean["Frequency_Total_Purchases"] = df_clean[purchase_cols].sum(axis=1)

    # Recency alias for explicit clarity
    df_clean["Recency_Days"] = df_clean["Recency"]

    # Average Order Value (AOV)
    df_clean["Avg_Order_Value"] = np.where(
        df_clean["Frequency_Total_Purchases"] > 0,
        df_clean["Monetary_Total_Spend"] / df_clean["Frequency_Total_Purchases"],
        0.0,
    )

    # 7. Channel & Behavioral Engagement Features
    # Web purchase share vs Store purchase share
    df_clean["Web_Purchase_Ratio"] = np.where(
        df_clean["Frequency_Total_Purchases"] > 0,
        df_clean["NumWebPurchases"] / df_clean["Frequency_Total_Purchases"],
        0.0,
    )
    df_clean["Store_Purchase_Ratio"] = np.where(
        df_clean["Frequency_Total_Purchases"] > 0,
        df_clean["NumStorePurchases"] / df_clean["Frequency_Total_Purchases"],
        0.0,
    )

    # Campaign responsiveness
    campaign_cols = ["AcceptedCmp1", "AcceptedCmp2", "AcceptedCmp3", "AcceptedCmp4", "AcceptedCmp5"]
    df_clean["Total_Accepted_Campaigns"] = df_clean[campaign_cols].sum(axis=1)
    df_clean["Has_Accepted_Any_Campaign"] = (df_clean["Total_Accepted_Campaigns"] > 0).astype(int)

    # Churn Risk Proxy definition:
    # A customer with high recency (inactive > 60 days), low web visits, and no campaign response
    df_clean["Is_Churn_Risk"] = np.where(
        (df_clean["Recency_Days"] >= 60) & (df_clean["Total_Accepted_Campaigns"] == 0) & (df_clean["Response"] == 0),
        1,
        0,
    )

    # 8. Drop Constant / Uninformative Columns
    cols_to_drop = ["Z_CostContact", "Z_Revenue"]
    df_clean = df_clean.drop(columns=[col for col in cols_to_drop if col in df_clean.columns])

    # Reset Index
    df_clean = df_clean.reset_index(drop=True)

    print(f"Preprocessing complete. Cleaned shape: {df_clean.shape}")
    return df_clean


def run_pipeline(input_path: str, output_csv_path: str):
    """Execute complete ingestion and preprocessing pipeline."""
    df_raw = load_raw_data(input_path)
    df_processed = preprocess_customer_data(df_raw)

    os.makedirs(os.path.dirname(output_csv_path), exist_ok=True)
    df_processed.to_csv(output_csv_path, index=False)
    print(f"Processed dataset saved to: {output_csv_path}")

    return df_processed


if __name__ == "__main__":
    input_file = os.path.join("Dataset", "marketing_campaign.csv")
    output_file = os.path.join("Dataset", "processed_customer_data.csv")
    run_pipeline(input_file, output_file)

