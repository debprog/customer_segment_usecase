"""
Step 2: RFM Scoring, Unsupervised Behavioral Clustering (K-Means),
and Predictive Churn & Lifetime Value (LTV) Modeling (XGBoost).
"""

import os
import joblib
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    roc_auc_score,
    silhouette_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier


def compute_rfm_scores(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate quintile scores (1-5) for Recency, Frequency, and Monetary,

    plus a weighted composite RFM score.
    """
    df = df.copy()

    # Recency Quintile (Lower recency is better -> higher score 5)
    df["R_Score"] = pd.qcut(
        df["Recency_Days"],
        q=5,
        labels=[5, 4, 3, 2, 1],
    ).astype(int)

    # Frequency Quintile (Higher frequency is better -> higher score 5)
    df["F_Score"] = pd.qcut(
        df["Frequency_Total_Purchases"].rank(method="first"),
        q=5,
        labels=[1, 2, 3, 4, 5],
    ).astype(int)

    # Monetary Quintile (Higher spend is better -> higher score 5)
    df["M_Score"] = pd.qcut(
        df["Monetary_Total_Spend"].rank(method="first"),
        q=5,
        labels=[1, 2, 3, 4, 5],
    ).astype(int)

    # RFM Combined String (e.g., '555', '111')
    df["RFM_Segment_Code"] = (
        df["R_Score"].astype(str)
        + df["F_Score"].astype(str)
        + df["M_Score"].astype(str)
    )

    # Weighted RFM Score (Weights: R=0.2, F=0.3, M=0.5)
    df["RFM_Weighted_Score"] = (
        (0.2 * df["R_Score"]) + (0.3 * df["F_Score"]) + (0.5 * df["M_Score"])
    ).round(2)

    return df


def perform_kmeans_clustering(
    df: pd.DataFrame, models_dir: str, n_clusters: int = 4
) -> tuple[pd.DataFrame, KMeans, StandardScaler]:
    """Standardizes behavioral features, tests silhouette scores, fits K-Means,

    and maps clusters to actionable business segment personas.
    """
    df = df.copy()

    cluster_features = [
        "Recency_Days",
        "Frequency_Total_Purchases",
        "Monetary_Total_Spend",
        "Avg_Order_Value",
        "Income",
        "Web_Purchase_Ratio",
        "Store_Purchase_Ratio",
        "NumWebVisitsMonth",
    ]

    X = df[cluster_features]

    # Standardize features (mean=0, variance=1)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Evaluate silhouette scores across k = 3, 4, 5, 6
    print("\n--- Evaluating K-Means Cluster Silhouette Scores ---")
    silhouette_dict = {}
    for k in [3, 4, 5, 6]:
        km_test = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = km_test.fit_predict(X_scaled)
        score = silhouette_score(X_scaled, labels)
        silhouette_dict[k] = score
        print(f"k = {k} | Silhouette Score: {score:.4f}")

    # Fit final K-Means model
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=15)
    df["Cluster_ID"] = kmeans.fit_predict(X_scaled)

    # Analyze Cluster Centroids to Assign Semantic Business Labels
    cluster_profiles = df.groupby("Cluster_ID")[
        ["Recency_Days", "Frequency_Total_Purchases", "Monetary_Total_Spend", "Income"]
    ].mean()
    print("\nCluster Centroid Profiles (Averages):")
    print(cluster_profiles)

    # Dynamic labeling based on centroid metrics
    segment_names = {}
    for c_id, row in cluster_profiles.iterrows():
        spend = row["Monetary_Total_Spend"]
        recency = row["Recency_Days"]

        # Spend tiers relative to overall average
        avg_spend = df["Monetary_Total_Spend"].mean()
        avg_recency = df["Recency_Days"].mean()

        if spend >= avg_spend and recency < avg_recency:
            segment_names[c_id] = "Loyal Champions"
        elif spend >= avg_spend and recency >= avg_recency:
            segment_names[c_id] = "At-Risk High-Spenders"
        elif spend < avg_spend and recency < avg_recency:
            segment_names[c_id] = "Potential Upsell"
        else:
            segment_names[c_id] = "Dormant / Low-Value"

    # Ensure all 4 unique names are assigned
    df["Segment_Name"] = df["Cluster_ID"].map(segment_names)

    # Save scaler and kmeans model
    os.makedirs(models_dir, exist_ok=True)
    joblib.dump(scaler, os.path.join(models_dir, "scaler.joblib"))
    joblib.dump(kmeans, os.path.join(models_dir, "kmeans_model.joblib"))
    print(f"Saved K-Means model & Scaler to: {models_dir}")

    return df, kmeans, scaler


def train_predictive_churn_model(
    df: pd.DataFrame, models_dir: str
) -> tuple[pd.DataFrame, XGBClassifier, dict]:
    """Trains an XGBoost Classifier to predict customer churn probability,

    calculates expected Customer Lifetime Value (LTV), and evaluates performance.
    """
    df = df.copy()

    feature_cols = [
        "Age",
        "Income",
        "Total_Children",
        "Family_Size",
        "Customer_Tenure_Days",
        "Recency_Days",
        "Frequency_Total_Purchases",
        "Monetary_Total_Spend",
        "Avg_Order_Value",
        "MntWines",
        "MntFruits",
        "MntMeatProducts",
        "MntFishProducts",
        "MntSweetProducts",
        "MntGoldProds",
        "NumDealsPurchases",
        "NumWebPurchases",
        "NumCatalogPurchases",
        "NumStorePurchases",
        "NumWebVisitsMonth",
        "Total_Accepted_Campaigns",
        "Has_Accepted_Any_Campaign",
        "RFM_Weighted_Score",
    ]

    target_col = "Is_Churn_Risk"

    X = df[feature_cols]
    y = df[target_col]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    # Initialize & train XGBoost model
    xgb_model = XGBClassifier(
        n_estimators=120,
        max_depth=4,
        learning_rate=0.08,
        subsample=0.85,
        colsample_bytree=0.85,
        random_state=42,
        eval_metric="logloss",
    )
    xgb_model.fit(X_train, y_train)

    # Evaluate on holdout test set
    y_pred = xgb_model.predict(X_test)
    y_pred_proba = xgb_model.predict_proba(X_test)[:, 1]

    roc_auc = roc_auc_score(y_test, y_pred_proba)
    acc = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred, output_dict=True)

    print("\n--- XGBoost Predictive Churn Model Evaluation ---")
    print(f"ROC-AUC Score: {roc_auc:.4f}")
    print(f"Accuracy:      {acc:.4f}")
    print(f"Precision (At-Risk class): {report['1']['precision']:.4f}")
    print(f"Recall (At-Risk class):    {report['1']['recall']:.4f}")
    print(f"F1-Score (At-Risk class):  {report['1']['f1-score']:.4f}")

    # Generate continuous churn probabilities for the entire customer base
    df["Churn_Probability"] = xgb_model.predict_proba(X)[:, 1].round(4)

    # Feature Importance
    feat_imp = pd.Series(xgb_model.feature_importances_, index=feature_cols).sort_values(
        ascending=False
    )
    print("\nTop 5 Churn Predictor Features:")
    print(feat_imp.head(5))

    # Calculate Predictive Customer Lifetime Value (LTV):
    # LTV = Annualized Monetary Spend * (1 - Churn Probability) * Margin/Retention Factor
    df["Retention_Probability"] = (1.0 - df["Churn_Probability"]).clip(lower=0.05)
    df["Predicted_LTV"] = (
        df["Monetary_Total_Spend"] * df["Retention_Probability"] * 1.5
    ).round(2)

    # Save XGBoost model
    joblib.dump(xgb_model, os.path.join(models_dir, "xgboost_churn_model.joblib"))
    print(f"Saved XGBoost Churn Model to: {models_dir}")

    eval_metrics = {
        "roc_auc": roc_auc,
        "accuracy": acc,
        "precision": report["1"]["precision"],
        "recall": report["1"]["recall"],
        "f1": report["1"]["f1-score"],
        "top_features": feat_imp.head(5).to_dict(),
    }

    return df, xgb_model, eval_metrics


def run_step2(
    input_csv: str, output_csv: str, models_dir: str
) -> tuple[pd.DataFrame, dict]:
    """Execute complete Step 2 pipeline."""
    print("=" * 60)
    print("STARTING STEP 2: RFM, CLUSTERING & PREDICTIVE MODELING")
    print("=" * 60)

    # 1. Load Processed Dataset
    df = pd.read_csv(input_csv)
    print(f"Loaded processed data: {df.shape}")

    # 2. RFM Scoring
    print("\n[1/3] Computing RFM Quintiles and Weighted Scores...")
    df = compute_rfm_scores(df)

    # 3. K-Means Behavioral Clustering
    print("\n[2/3] Performing K-Means Behavioral Clustering...")
    df, kmeans, scaler = perform_kmeans_clustering(df, models_dir=models_dir, n_clusters=4)

    # 4. Supervised Predictive Churn & LTV Modeling
    print("\n[3/3] Training XGBoost Churn & LTV Predictive Models...")
    df, xgb_model, eval_metrics = train_predictive_churn_model(
        df, models_dir=models_dir
    )

    # 5. Save Segmented Dataset
    os.makedirs(os.path.dirname(output_csv), exist_ok=True)
    df.to_csv(output_csv, index=False)
    print(f"\nSaved segmented customer dataset to: {output_csv}")

    print("\nSegment Distribution Summary:")
    print(df["Segment_Name"].value_counts())

    return df, eval_metrics


if __name__ == "__main__":
    in_file = os.path.join("Dataset", "processed_customer_data.csv")
    out_file = os.path.join("Dataset", "segmented_customers.csv")
    m_dir = "models"
    run_step2(in_file, out_file, m_dir)

