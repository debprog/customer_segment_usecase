"""
Run Demo: Execute LangGraph Retention Agent on an At-Risk Customer
Uses local Ollama model qwen2.5:3b to generate campaign copy.
"""

import os
import sys

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import pandas as pd
from src.agent.graph import retention_agent_app


def find_top_category(row: pd.Series) -> tuple[str, float]:
    """Identify the customer's top spending category."""
    cats = {
        "Fine Wines": row.get("MntWines", 0),
        "Gourmet Meats": row.get("MntMeatProducts", 0),
        "Fresh Fruits": row.get("MntFruits", 0),
        "Fish & Seafood": row.get("MntFishProducts", 0),
        "Artisanal Sweets": row.get("MntSweetProducts", 0),
        "Gold Products": row.get("MntGoldProds", 0),
    }
    top_cat = max(cats, key=cats.get)
    return top_cat, cats[top_cat]


def run_customer_retention_demo(customer_id: int = None):
    # 1. Load Segmented Customers Dataset
    csv_path = os.path.join("Dataset", "segmented_customers.csv")
    df = pd.read_csv(csv_path)

    # If no ID specified, select an At-Risk High-Spender with high churn risk
    if customer_id is None:
        at_risk_df = df[
            (df["Segment_Name"] == "At-Risk High-Spenders") & (df["Churn_Probability"] >= 0.75)
        ]
        if not at_risk_df.empty:
            cust_row = at_risk_df.iloc[0]
        else:
            cust_row = df.iloc[0]
    else:
        matched = df[df["ID"] == customer_id]
        if matched.empty:
            print(f"Customer #{customer_id} not found. Using default.")
            cust_row = df.iloc[0]
        else:
            cust_row = matched.iloc[0]

    top_cat, top_spend = find_top_category(cust_row)

    # Synthesize realistic customer name for demo
    sample_names = {
        5524: "Sarah Jenkins",
        2174: "David Miller",
        4141: "Elena Rostova",
        6182: "Marcus Vance",
    }
    cust_name = sample_names.get(int(cust_row["ID"]), f"Customer {cust_row['ID']}")

    customer_payload = {
        "id": int(cust_row["ID"]),
        "name": cust_name,
        "age": int(cust_row["Age"]),
        "income": float(cust_row["Income"]),
        "marital_status": str(cust_row["Marital_Status_Clean"]),
        "children": int(cust_row["Total_Children"]),
        "segment_name": str(cust_row["Segment_Name"]),
        "rfm_score": float(cust_row["RFM_Weighted_Score"]),
        "recency_days": int(cust_row["Recency_Days"]),
        "total_purchases": int(cust_row["Frequency_Total_Purchases"]),
        "total_spend": float(cust_row["Monetary_Total_Spend"]),
        "churn_probability": float(cust_row["Churn_Probability"]),
        "predicted_ltv": float(cust_row["Predicted_LTV"]),
        "top_category": top_cat,
        "top_category_spend": float(top_spend),
    }

    initial_state = {
        "customer": customer_payload,
        "persona_summary": None,
        "urgency_level": None,
        "recommended_incentive": None,
        "recommended_channels": None,
        "email_subject": None,
        "email_body": None,
        "sms_copy": None,
        "call_to_action": None,
        "quality_status": None,
        "quality_feedback": None,
        "revision_count": 0,
    }

    print("=" * 70)
    print("STARTING LANGGRAPH RETENTION WORKFLOW (Ollama qwen2.5:3b)")
    print("=" * 70)
    print(f"Target Customer: {customer_payload['name']} (ID: #{customer_payload['id']})")
    print(f"Segment:         {customer_payload['segment_name']}")
    print(f"Churn Risk:      {customer_payload['churn_probability'] * 100:.1f}%")
    print(f"Predicted LTV:   ${customer_payload['predicted_ltv']:,.2f}")
    print(f"Favorite Cat:    {customer_payload['top_category']} (${customer_payload['top_category_spend']:,.2f})")
    print("-" * 70)

    # Execute Graph
    final_output = retention_agent_app.invoke(initial_state)

    print("\n" + "=" * 70)
    print("FINAL AGENT RETENTION CAMPAIGN PACKAGE")
    print("=" * 70)
    print(f"Persona Summary:\n{final_output['persona_summary']}")
    print(f"\nUrgency Level:        {final_output['urgency_level']}")
    print(f"Incentive Selected:   {final_output['recommended_incentive']}")
    print(f"Target Channels:      {', '.join(final_output['recommended_channels'])}")
    print(f"Quality Gate Status:  {final_output['quality_status']} ({final_output['quality_feedback']})")
    print("\n--- GENERATED CAMPAIGN ASSETS ---")
    print(f"\n[EMAIL SUBJECT]:\n{final_output['email_subject']}")
    print(f"\n[EMAIL BODY]:\n{final_output['email_body']}")
    print(f"\n[SMS COPY (< 160 chars)]:\n{final_output['sms_copy']}")
    print(f"\n[CALL TO ACTION BUTTON]:\n[{final_output['call_to_action']}]")
    print("=" * 70)

    return final_output


if __name__ == "__main__":
    # Test on customer ID 5524 (an At-Risk High-Spender)
    run_customer_retention_demo(customer_id=5524)
