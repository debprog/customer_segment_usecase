"""
Agent Execution Nodes for LangGraph Retention Workflow
Powered by local Ollama model (qwen2.5:3b)
"""

import json
import re
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_ollama import ChatOllama
from src.agent.state import RetentionCampaignState


def get_llm(model_name: str = "qwen2.5:3b", temperature: float = 0.3) -> ChatOllama:
    """Initialize local Ollama Chat model."""
    return ChatOllama(
        model=model_name,
        base_url="http://127.0.0.1:11434",
        temperature=temperature,
    )


# -----------------------------------------------------------------------------
# Node 1: Profile & Behavioral Intelligence Analyst
# -----------------------------------------------------------------------------
def profile_analyst_node(state: RetentionCampaignState) -> dict:
    """Analyzes customer metrics, segment, and churn probability to formulate

    a concise persona brief and urgency level.
    """
    cust = state["customer"]
    churn_risk = cust.get("churn_probability", 0.0)
    segment = cust.get("segment_name", "General")
    top_cat = cust.get("top_category", "Products")

    # Determine urgency level based on churn probability and segment
    if churn_risk >= 0.70:
        urgency = "CRITICAL_WIN_BACK"
    elif segment == "Loyal Champions":
        urgency = "LOYALTY_REWARD"
    elif segment == "At-Risk High-Spenders":
        urgency = "HIGH_PRIORITY_WIN_BACK"
    elif segment == "Potential Upsell":
        urgency = "UPSELL_GROWTH"
    else:
        urgency = "RE_ENGAGEMENT"

    persona = (
        f"Customer #{cust.get('id')} ({cust.get('name', 'Valued Customer')}) is a "
        f"{cust.get('age', 40)}-year-old in the '{segment}' segment with an income of "
        f"${cust.get('income', 0):,.0f}. Total spend is ${cust.get('total_spend', 0):,.2f} "
        f"with top affinity in '{top_cat}' (${cust.get('top_category_spend', 0):,.2f}). "
        f"They have been inactive for {cust.get('recency_days', 0)} days with a "
        f"churn risk probability of {churn_risk * 100:.1f}%."
    )

    print(f"\n[Agent 1: Profile Analyst] Generated persona for Customer #{cust.get('id')}")
    print(f"Urgency Level: {urgency}")

    return {
        "persona_summary": persona,
        "urgency_level": urgency,
    }


# -----------------------------------------------------------------------------
# Node 2: Retention Strategy & Incentive Recommendation Agent
# -----------------------------------------------------------------------------
def strategy_matcher_node(state: RetentionCampaignState) -> dict:
    """Determines high-ROI retention incentive and target delivery channels

    based on customer LTV and urgency.
    """
    urgency = state.get("urgency_level", "RE_ENGAGEMENT")
    cust = state["customer"]
    top_cat = cust.get("top_category", "Favorites")
    ltv = cust.get("predicted_ltv", 500.0)

    if urgency in ["CRITICAL_WIN_BACK", "HIGH_PRIORITY_WIN_BACK"]:
        # High value at stake: offer meaningful voucher or exclusive gift
        if ltv >= 800:
            incentive = f"$50 Private Credit toward your next {top_cat} purchase (Min spend $120)"
        else:
            incentive = f"Exclusive 25% Off Win-Back Pass on all {top_cat}"
        channels = ["Email", "SMS", "In-App Banner"]

    elif urgency == "LOYALTY_REWARD":
        # Loyal customers: protect margins, reward status & early access
        incentive = f"VIP Early Access to Private Reserve {top_cat} + 2x Loyalty Reward Points"
        channels = ["Email", "In-App Banner"]

    elif urgency == "UPSELL_GROWTH":
        incentive = f"Curated Sommelier Pairing: Complimentary Gift with 2 {top_cat} Selections"
        channels = ["Email", "Push Notification"]

    else:
        incentive = "15% Off Your Next Order + We'd Love Your Feedback Survey"
        channels = ["Email"]

    print(f"[Agent 2: Strategy Matcher] Assigned Incentive: {incentive}")
    print(f"Target Channels: {channels}")

    return {
        "recommended_incentive": incentive,
        "recommended_channels": channels,
    }


# -----------------------------------------------------------------------------
# Node 3: Creative Copywriter Agent (Local Ollama LLM)
# -----------------------------------------------------------------------------
def creative_copywriter_node(state: RetentionCampaignState) -> dict:
    """Uses local Ollama model (qwen2.5:3b) to draft personalized marketing copy

    across Email, SMS, and Call-to-Action.
    """
    cust = state["customer"]
    persona = state.get("persona_summary", "")
    incentive = state.get("recommended_incentive", "")
    urgency = state.get("urgency_level", "")
    feedback = state.get("quality_feedback", None)

    llm = get_llm(model_name="qwen2.5:3b", temperature=0.3)

    system_prompt = (
        "You are an elite, empathetic direct-response marketing copywriter for a premium retailer. "
        "Your task is to write high-converting, personalized campaign copy for an individual customer. "
        "You must respond ONLY with a valid, raw JSON object containing the exact keys: "
        "'email_subject', 'email_body', 'sms_copy', 'call_to_action'. "
        "Do not include markdown code block markers (like ```json), explanations, or notes outside the JSON."
    )

    revision_context = f"\nPREVIOUS QUALITY FEEDBACK TO FIX: {feedback}" if feedback else ""

    user_prompt = f"""
Customer Context:
- Name: {cust.get('name', 'Valued Customer')}
- Segment: {cust.get('segment_name')}
- Urgency: {urgency}
- Top Category: {cust.get('top_category')}
- Persona: {persona}
- Assigned Incentive: {incentive}
{revision_context}

Requirements:
1. email_subject: Compelling, personalized, under 70 characters.
2. email_body: Warm, authentic, references their affinity for {cust.get('top_category')}, clearly offers the assigned incentive, and includes their name. (2-3 paragraphs).
3. sms_copy: Punchy text message strictly under 160 characters mentioning the incentive.
4. call_to_action: Action button text (e.g., 'Claim Your $50 Credit').

Return ONLY the JSON object.
"""

    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt),
    ]

    print("[Agent 3: Creative Copywriter] Invoking Ollama (qwen2.5:3b)...")
    response = llm.invoke(messages)
    raw_content = response.content.strip()

    # Clean potential markdown wrapping
    cleaned_json = raw_content
    if "```json" in cleaned_json:
        cleaned_json = cleaned_json.split("```json")[1].split("```")[0].strip()
    elif "```" in cleaned_json:
        cleaned_json = cleaned_json.split("```")[1].split("```")[0].strip()

    try:
        parsed = json.loads(cleaned_json)
        email_subj = parsed.get("email_subject", "Special Offer For You")
        email_body = parsed.get("email_body", f"Hello {cust.get('name')}, we have an exclusive offer for you.")
        sms = parsed.get("sms_copy", f"Special offer for {cust.get('name')}: {incentive}")
        cta = parsed.get("call_to_action", "Claim Offer")
    except Exception as e:
        print(f"Warning: JSON parse fallback triggered ({e}). Extracting text.")
        email_subj = f"Exclusive Invitation for {cust.get('name')}"
        email_body = raw_content
        sms = f"{cust.get('name')}, we miss you! Enjoy {incentive}. Shop now: [link]"
        cta = "Unlock Your Offer"

    return {
        "email_subject": email_subj,
        "email_body": email_body,
        "sms_copy": sms,
        "call_to_action": cta,
    }


# -----------------------------------------------------------------------------
# Node 4: Quality & Policy Gate (Supervisory Node)
# -----------------------------------------------------------------------------
def quality_gate_node(state: RetentionCampaignState) -> dict:
    """Validates the generated campaign copy against length, tone, and placeholder checks.

    Flags for rewrite if defects are detected (up to 2 revisions).
    """
    subject = state.get("email_subject", "")
    body = state.get("email_body", "")
    sms = state.get("sms_copy", "")
    revisions = state.get("revision_count", 0)

    issues = []

    # Check 1: Unrendered placeholders like [Customer Name] or [Insert ...]
    if re.search(r"\[.*?name.*?\]", body, re.IGNORECASE) or re.search(r"\[.*?discount.*?\]", body, re.IGNORECASE):
        issues.append("Unfilled bracket placeholders detected in email body.")

    # Check 2: SMS character length (must be <= 220 chars)
    if len(sms) > 220:
        issues.append(f"SMS length ({len(sms)} chars) exceeds maximum allowable limit of 220 chars.")

    # Check 3: Missing essential content
    if len(subject) < 5 or len(body) < 30:
        issues.append("Generated copy is too short or incomplete.")

    if issues and revisions < 2:
        status = "REVISE"
        feedback = "; ".join(issues)
        print(f"[Quality Gate] REJECTED (Attempt #{revisions + 1}): {feedback}")
    else:
        status = "APPROVED"
        feedback = "Passed all compliance, length, and quality standards."
        print(f"[Quality Gate] APPROVED campaign copy successfully.")

    return {
        "quality_status": status,
        "quality_feedback": feedback,
        "revision_count": revisions + 1,
    }


# -----------------------------------------------------------------------------
# Conditional Router Function
# -----------------------------------------------------------------------------
def route_after_quality_gate(state: RetentionCampaignState) -> str:
    """Routes back to copywriter if revisions are needed, else terminates at END."""
    if state.get("quality_status") == "REVISE":
        return "creative_copywriter"
    return "__end__"

