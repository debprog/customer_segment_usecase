"""
LangGraph Retention Agent Workflow Graph
Compiles the multi-agent StateGraph for customer retention personalization.
"""

from langgraph.graph import END, START, StateGraph
from src.agent.nodes import (
    creative_copywriter_node,
    profile_analyst_node,
    quality_gate_node,
    route_after_quality_gate,
    strategy_matcher_node,
)
from src.agent.state import RetentionCampaignState


def build_retention_graph():
    """Builds and compiles the 4-node LangGraph retention workflow."""
    workflow = StateGraph(RetentionCampaignState)

    # 1. Register Nodes
    workflow.add_node("profile_analyst", profile_analyst_node)
    workflow.add_node("strategy_matcher", strategy_matcher_node)
    workflow.add_node("creative_copywriter", creative_copywriter_node)
    workflow.add_node("quality_gate", quality_gate_node)

    # 2. Linear Flow
    workflow.add_edge(START, "profile_analyst")
    workflow.add_edge("profile_analyst", "strategy_matcher")
    workflow.add_edge("strategy_matcher", "creative_copywriter")
    workflow.add_edge("creative_copywriter", "quality_gate")

    # 3. Conditional Supervisory Loop (Quality Gate -> END or Retry)
    workflow.add_conditional_edges(
        "quality_gate",
        route_after_quality_gate,
        {
            "creative_copywriter": "creative_copywriter",
            "__end__": END,
        },
    )

    app = workflow.compile()
    return app


# Singleton compiled app instance
retention_agent_app = build_retention_graph()

