"""
Retention Campaign State Definition
Defines the shared state schema flowing through the LangGraph retention workflow.
"""

from typing import List, Optional
from typing_extensions import TypedDict


class CustomerProfile(TypedDict):
    id: int
    name: str
    age: int
    income: float
    marital_status: str
    children: int
    segment_name: str
    rfm_score: float
    recency_days: int
    total_purchases: int
    total_spend: float
    churn_probability: float
    predicted_ltv: float
    top_category: str
    top_category_spend: float


class RetentionCampaignState(TypedDict):
    customer: CustomerProfile
    persona_summary: Optional[str]
    urgency_level: Optional[str]
    recommended_incentive: Optional[str]
    recommended_channels: Optional[List[str]]
    email_subject: Optional[str]
    email_body: Optional[str]
    sms_copy: Optional[str]
    call_to_action: Optional[str]
    quality_status: Optional[str]
    quality_feedback: Optional[str]
    revision_count: int

