"""
Database Layer (SQLite) for Customer Segmentation & Retention Platform
Provides high-performance queries for customer records, KPI aggregates, and campaign logging.
"""

import os
import sqlite3
from typing import Any, Dict, List, Optional
import numpy as np
import pandas as pd

DB_PATH = os.path.join("data", "customer_retention.db")


def get_connection() -> sqlite3.Connection:
    """Returns a SQLite connection with dict-like row factory."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(csv_path: str = os.path.join("Dataset", "segmented_customers.csv")) -> int:
    """Initializes SQLite database and populates with segmented customer data."""
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Segmented customer dataset not found at {csv_path}")

    df = pd.read_csv(csv_path)

    # Attach synthetic realistic names for demo presentation
    sample_names = {
        5524: "Sarah Jenkins",
        2174: "David Miller",
        4141: "Elena Rostova",
        6182: "Marcus Vance",
        2125: "Arthur Pendelton",
        1371: "Claire Montgomery",
        1357: "Robert Sterling",
    }
    df["Customer_Name"] = df["ID"].map(lambda cid: sample_names.get(int(cid), f"Customer {cid}"))

    # Compute top spending category per customer
    def get_top_category(row):
        cats = {
            "Fine Wines": row.get("MntWines", 0),
            "Gourmet Meats": row.get("MntMeatProducts", 0),
            "Fresh Fruits": row.get("MntFruits", 0),
            "Fish & Seafood": row.get("MntFishProducts", 0),
            "Artisanal Sweets": row.get("MntSweetProducts", 0),
            "Gold Products": row.get("MntGoldProds", 0),
        }
        best = max(cats, key=cats.get)
        return pd.Series([best, cats[best]], index=["Top_Category", "Top_Category_Spend"])

    top_cat_df = df.apply(get_top_category, axis=1)
    df["Top_Category"] = top_cat_df["Top_Category"]
    df["Top_Category_Spend"] = top_cat_df["Top_Category_Spend"]

    conn = get_connection()
    cursor = conn.cursor()

    # Drop old tables if re-initializing
    cursor.execute("DROP TABLE IF EXISTS customers;")
    cursor.execute("DROP TABLE IF EXISTS campaigns;")

    # Ingest customers table
    df.to_sql("customers", conn, if_exists="replace", index=False)

    # Create indexes for sub-millisecond API query performance
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_cust_id ON customers (ID);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_cust_segment ON customers (Segment_Name);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_cust_churn ON customers (Churn_Probability);")

    # Create campaigns history table
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS campaigns (
            campaign_id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            customer_name TEXT,
            segment_name TEXT,
            urgency_level TEXT,
            incentive TEXT,
            channels TEXT,
            email_subject TEXT,
            email_body TEXT,
            sms_copy TEXT,
            call_to_action TEXT,
            quality_status TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES customers(ID)
        );
    """
    )

    conn.commit()
    count = cursor.execute("SELECT count(*) FROM customers").fetchone()[0]
    conn.close()
    print(f"SQLite database initialized at {DB_PATH} with {count} customer records.")
    return count


def get_customer_by_id(customer_id: int) -> Optional[Dict[str, Any]]:
    """Fetch single customer profile by ID."""
    conn = get_connection()
    cursor = conn.cursor()
    row = cursor.execute("SELECT * FROM customers WHERE ID = ?", (customer_id,)).fetchone()
    conn.close()
    if row:
        return dict(row)
    return None


def get_customers(
    segment: Optional[str] = None,
    min_churn_risk: Optional[float] = None,
    search: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[List[Dict[str, Any]], int]:
    """Fetch filtered, paginated customer records."""
    conn = get_connection()
    cursor = conn.cursor()

    query = "SELECT * FROM customers WHERE 1=1"
    count_query = "SELECT COUNT(*) FROM customers WHERE 1=1"
    params = []

    if segment and segment != "All":
        query += " AND Segment_Name = ?"
        count_query += " AND Segment_Name = ?"
        params.append(segment)

    if min_churn_risk is not None and min_churn_risk > 0:
        query += " AND Churn_Probability >= ?"
        count_query += " AND Churn_Probability >= ?"
        params.append(min_churn_risk)

    if search:
        query += " AND (CAST(ID AS TEXT) LIKE ? OR Customer_Name LIKE ?)"
        count_query += " AND (CAST(ID AS TEXT) LIKE ? OR Customer_Name LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])

    # Total count
    total_count = cursor.execute(count_query, params).fetchone()[0]

    # Pagination
    query += " ORDER BY Churn_Probability DESC, Monetary_Total_Spend DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])

    rows = cursor.execute(query, params).fetchall()
    conn.close()

    return [dict(r) for r in rows], total_count


def get_kpi_summary() -> Dict[str, Any]:
    """Compute aggregate executive KPIs for dashboard ribbon and API."""
    conn = get_connection()
    cursor = conn.cursor()

    total_customers = cursor.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
    total_revenue = cursor.execute("SELECT SUM(Monetary_Total_Spend) FROM customers").fetchone()[0]
    avg_churn_risk = cursor.execute("SELECT AVG(Churn_Probability) FROM customers").fetchone()[0]
    avg_ltv = cursor.execute("SELECT AVG(Predicted_LTV) FROM customers").fetchone()[0]

    # At-risk revenue: total spend of customers with Churn_Probability >= 0.70
    at_risk_revenue = cursor.execute(
        "SELECT SUM(Monetary_Total_Spend) FROM customers WHERE Churn_Probability >= 0.70"
    ).fetchone()[0] or 0.0

    at_risk_count = cursor.execute(
        "SELECT COUNT(*) FROM customers WHERE Churn_Probability >= 0.70"
    ).fetchone()[0]

    # Segment counts
    segment_rows = cursor.execute(
        """
        SELECT Segment_Name, COUNT(*) as count, AVG(Churn_Probability) as avg_churn, AVG(Monetary_Total_Spend) as avg_spend
        FROM customers
        GROUP BY Segment_Name
        ORDER BY count DESC
    """
    ).fetchall()

    segments = [dict(r) for r in segment_rows]

    # Campaigns count
    total_campaigns = cursor.execute("SELECT COUNT(*) FROM campaigns").fetchone()[0]

    conn.close()

    return {
        "total_customers": total_customers,
        "total_revenue": round(total_revenue, 2),
        "at_risk_revenue": round(at_risk_revenue, 2),
        "at_risk_count": at_risk_count,
        "at_risk_percentage": round((at_risk_count / total_customers) * 100, 1) if total_customers else 0,
        "average_churn_rate": round(avg_churn_risk * 100, 1),
        "average_ltv": round(avg_ltv, 2),
        "active_campaigns_count": total_campaigns,
        "segments": segments,
    }


def log_campaign(campaign_data: Dict[str, Any]) -> int:
    """Save generated campaign to the database."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO campaigns (
            customer_id, customer_name, segment_name, urgency_level,
            incentive, channels, email_subject, email_body, sms_copy,
            call_to_action, quality_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """,
        (
            campaign_data.get("customer_id"),
            campaign_data.get("customer_name"),
            campaign_data.get("segment_name"),
            campaign_data.get("urgency_level"),
            campaign_data.get("incentive"),
            ", ".join(campaign_data.get("channels", [])),
            campaign_data.get("email_subject"),
            campaign_data.get("email_body"),
            campaign_data.get("sms_copy"),
            campaign_data.get("call_to_action"),
            campaign_data.get("quality_status"),
        ),
    )

    campaign_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return campaign_id


if __name__ == "__main__":
    init_db()
    kpi = get_kpi_summary()
    print("KPI Summary:", kpi)

