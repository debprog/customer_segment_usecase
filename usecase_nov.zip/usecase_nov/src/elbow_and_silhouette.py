"""
Elbow Curve and Silhouette Score Analysis
Computes and visualizes Inertia (WCSS) and Silhouette Scores for k = 2 to 10
to mathematically justify the optimal number of customer clusters.
"""

import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler


def compute_and_plot_elbow_silhouette(
    csv_path: str, output_image_path: str, k_range: range = range(2, 11)
):
    # 1. Load Data
    df = pd.read_csv(csv_path)

    cluster_features = [
        "Recency_Days",
        "Frequency_Total_Purchases",
        "Monetary_Total_Spend",
        "Avg_Order_Value",
        "Income",
        "Web_Purchase_Ratio",
        "Store_Purchase_Ratio",
        "NumWebVisitsMonth",
    ]

    X = df[cluster_features]

    # Standardize
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    inertias = []
    silhouette_scores = []
    k_values = list(k_range)

    print("=" * 60)
    print("COMPUTING ELBOW (INERTIA) & SILHOUETTE SCORES (k = 2 to 10)")
    print("=" * 60)

    for k in k_values:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = kmeans.fit_predict(X_scaled)
        inertia = kmeans.inertia_
        sil_score = silhouette_score(X_scaled, labels)

        inertias.append(inertia)
        silhouette_scores.append(sil_score)
        print(f"k = {k:2d} | Inertia (WCSS): {inertia:10.2f} | Silhouette Score: {sil_score:.4f}")

    # 2. Plot Dual Evaluation Curves
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6), dpi=300)
    fig.patch.set_facecolor("#fafafa")

    # Left Plot: Elbow Method (Inertia)
    ax1.plot(k_values, inertias, marker="o", markersize=8, color="#1e88e5", linewidth=2.5, label="Inertia (WCSS)")
    ax1.axvline(x=4, color="#d32f2f", linestyle="--", linewidth=1.8, label="Selected k = 4 (Elbow Point)")
    ax1.set_title("A. The Elbow Method (WCSS vs. Number of Clusters k)", fontsize=13, fontweight="bold", pad=12)
    ax1.set_xlabel("Number of Clusters (k)", fontsize=11, fontweight="bold")
    ax1.set_ylabel("Inertia (Within-Cluster Sum of Squares)", fontsize=11, fontweight="bold")
    ax1.set_xticks(k_values)
    ax1.grid(True, linestyle="--", alpha=0.6)
    ax1.set_facecolor("#ffffff")
    ax1.legend(loc="upper right", frameon=True, fontsize=10)

    # Highlight point k=4
    ax1.scatter([4], [inertias[k_values.index(4)]], color="#d32f2f", s=140, zorder=5)
    ax1.annotate(
        f"k=4\nInertia: {inertias[k_values.index(4)]:.1f}",
        xy=(4, inertias[k_values.index(4)]),
        xytext=(4.3, inertias[k_values.index(4)] + 400),
        arrowprops=dict(facecolor="#d32f2f", shrink=0.08, width=1.5, headwidth=7),
        fontsize=9,
        fontweight="bold",
        color="#d32f2f",
    )

    # Right Plot: Silhouette Score Curve
    ax2.plot(k_values, silhouette_scores, marker="s", markersize=8, color="#2e7d32", linewidth=2.5, label="Silhouette Score")
    ax2.axvline(x=4, color="#d32f2f", linestyle="--", linewidth=1.8, label="Selected k = 4")
    ax2.set_title("B. Silhouette Score vs. Number of Clusters k", fontsize=13, fontweight="bold", pad=12)
    ax2.set_xlabel("Number of Clusters (k)", fontsize=11, fontweight="bold")
    ax2.set_ylabel("Silhouette Score (Cluster Separation)", fontsize=11, fontweight="bold")
    ax2.set_xticks(k_values)
    ax2.grid(True, linestyle="--", alpha=0.6)
    ax2.set_facecolor("#ffffff")
    ax2.legend(loc="upper right", frameon=True, fontsize=10)

    # Highlight point k=4
    ax2.scatter([4], [silhouette_scores[k_values.index(4)]], color="#d32f2f", s=140, zorder=5)
    ax2.annotate(
        f"k=4\nScore: {silhouette_scores[k_values.index(4)]:.4f}",
        xy=(4, silhouette_scores[k_values.index(4)]),
        xytext=(4.3, silhouette_scores[k_values.index(4)] + 0.015),
        arrowprops=dict(facecolor="#d32f2f", shrink=0.08, width=1.5, headwidth=7),
        fontsize=9,
        fontweight="bold",
        color="#d32f2f",
    )

    plt.suptitle("Cluster Quality Evaluation: Elbow Method & Silhouette Analysis", fontsize=15, fontweight="heavy", y=0.98)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    os.makedirs(os.path.dirname(output_image_path), exist_ok=True)
    plt.savefig(output_image_path, dpi=300, bbox_inches="tight")
    plt.close()

    print(f"\nElbow & Silhouette curve saved to: {output_image_path}")

    # Return summary DataFrame
    results_df = pd.DataFrame({"k": k_values, "Inertia": inertias, "Silhouette_Score": silhouette_scores})
    return results_df


if __name__ == "__main__":
    csv_file = os.path.join("Dataset", "processed_customer_data.csv")
    out_img = os.path.join("visualizations", "elbow_and_silhouette_analysis.png")
    compute_and_plot_elbow_silhouette(csv_file, out_img)

