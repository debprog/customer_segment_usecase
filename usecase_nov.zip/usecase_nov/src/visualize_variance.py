"""
Feature Variance Visualization
Analyzes and plots the variance of all numerical features in the processed dataset.
"""

import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler


def plot_feature_variance(csv_path: str, output_image_path: str):
    # 1. Load Data
    df = pd.read_csv(csv_path)

    # Exclude ID, dates, and non-numeric columns
    numeric_df = df.select_dtypes(include=[np.number]).copy()
    if "ID" in numeric_df.columns:
        numeric_df = numeric_df.drop(columns=["ID"])

    # 2. Compute Raw Variance & Normalized Variance
    raw_var = numeric_df.var()

    # Min-Max Scaling so all columns are in [0, 1] for fair variance comparison
    scaler = MinMaxScaler()
    scaled_data = scaler.fit_transform(numeric_df)
    normalized_var = pd.Series(scaled_data.var(axis=0), index=numeric_df.columns)

    # Create summary DataFrame
    var_summary = pd.DataFrame(
        {
            "Feature": numeric_df.columns,
            "Raw_Variance": raw_var.values,
            "Log10_Raw_Var": np.log10(np.maximum(raw_var.values, 1e-6)),
            "Normalized_Variance": normalized_var.values,
            "Mean": numeric_df.mean().values,
            "Std_Dev": numeric_df.std().values,
        }
    )

    # Sort by Normalized Variance descending
    var_summary = var_summary.sort_values(by="Normalized_Variance", ascending=True)

    # 3. Categorize Features for Color Coding
    def categorize(feature):
        if any(term in feature for term in ["Mnt", "Spend", "Purchases", "Recency", "Avg_Order"]):
            return "RFM & Purchasing"
        elif any(term in feature for term in ["Age", "Income", "Children", "Family", "Year_Birth"]):
            return "Demographics"
        elif any(term in feature for term in ["Cmp", "Campaign", "Response", "Churn"]):
            return "Campaign & Retention"
        else:
            return "Channel & Behavioral"

    var_summary["Category"] = var_summary["Feature"].apply(categorize)
    category_palette = {
        "RFM & Purchasing": "#2b5c8f",
        "Demographics": "#2e7d32",
        "Campaign & Retention": "#d32f2f",
        "Channel & Behavioral": "#f57c00",
    }
    colors = [category_palette[cat] for cat in var_summary["Category"]]

    # 4. Generate Visualization
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 12), dpi=300)
    fig.patch.set_facecolor("#fafafa")

    # Subplot 1: Normalized Variance (Apples-to-Apples)
    y_pos = np.arange(len(var_summary))
    bars1 = ax1.barh(y_pos, var_summary["Normalized_Variance"], color=colors, height=0.75, edgecolor="none")
    ax1.set_yticks(y_pos)
    ax1.set_yticklabels(var_summary["Feature"], fontsize=9, fontweight="medium")
    ax1.set_xlabel("Normalized Variance (Min-Max Scaled [0, 1])", fontsize=11, fontweight="bold", labelpad=10)
    ax1.set_title(
        "A. Normalized Feature Variance\n(Equal-Scale Comparison of Information Spread)",
        fontsize=12,
        fontweight="bold",
        pad=12,
    )
    ax1.grid(axis="x", linestyle="--", alpha=0.5)
    ax1.set_facecolor("#ffffff")

    # Add data labels
    for bar in bars1:
        width = bar.get_width()
        ax1.text(
            width + 0.002,
            bar.get_y() + bar.get_height() / 2,
            f"{width:.3f}",
            va="center",
            fontsize=7.5,
            color="#333333",
        )

    # Subplot 2: Log10 of Raw Variance
    bars2 = ax2.barh(y_pos, var_summary["Log10_Raw_Var"], color=colors, height=0.75, edgecolor="none", alpha=0.85)
    ax2.set_yticks(y_pos)
    ax2.set_yticklabels([])  # Hide y labels since shared
    ax2.set_xlabel("Log10(Raw Variance)", fontsize=11, fontweight="bold", labelpad=10)
    ax2.set_title(
        "B. Raw Variance Magnitude (Log10 Scale)\n(Shows Absolute Magnitude Differences)",
        fontsize=12,
        fontweight="bold",
        pad=12,
    )
    ax2.grid(axis="x", linestyle="--", alpha=0.5)
    ax2.set_facecolor("#ffffff")

    # Add legend for categories
    handles = [
        plt.Rectangle((0, 0), 1, 1, color=color, label=label)
        for label, color in category_palette.items()
    ]
    ax1.legend(handles=handles, loc="lower right", title="Feature Group", frameon=True, fontsize=9)

    plt.suptitle(
        "Comprehensive Variance Analysis Across All Features\n(Dataset: Processed Customer Data, N = 2,236)",
        fontsize=15,
        fontweight="heavy",
        y=0.98,
    )
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    os.makedirs(os.path.dirname(output_image_path), exist_ok=True)
    plt.savefig(output_image_path, dpi=300, bbox_inches="tight")
    plt.close()

    print(f"Variance plot successfully saved to: {output_image_path}")
    return var_summary


if __name__ == "__main__":
    csv_file = os.path.join("Dataset", "processed_customer_data.csv")
    out_img = os.path.join("visualizations", "feature_variance_analysis.png")
    summary = plot_feature_variance(csv_file, out_img)
    print("\nTop 10 High-Variance Features (Normalized):")
    print(
        summary.sort_values(by="Normalized_Variance", ascending=False)[
            ["Feature", "Normalized_Variance", "Category"]
        ].head(10).to_string(index=False)
    )

