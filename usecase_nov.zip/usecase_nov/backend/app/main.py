"""
FastAPI Backend Server
Customer Segmentation & AI-Driven Retention Platform
"""

import os
import sys
from typing import Any, Dict, List, Optional
from fastapi import FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.agent.graph import retention_agent_app
from src.database import (
    get_customer_by_id,
    get_customers,
    get_kpi_summary,
    init_db,
    log_campaign,
)

# -----------------------------------------------------------------------------
# FastAPI App Initialization
# -----------------------------------------------------------------------------
app = FastAPI(
    title="RetentionAI - Customer Segmentation & Retention API",
    description="Backend API for RFM Segmentation, Churn Analytics, and LangGraph Agent Retention Campaigns.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# -----------------------------------------------------------------------------
# Pydantic Schemas
# -----------------------------------------------------------------------------
class CampaignGenerateRequest(BaseModel):
    customer_id: int = Field(..., description="Target Customer ID", example=2125)
    model_name: Optional[str] = Field("qwen2.5:3b", description="Ollama model to use")


class CampaignResponse(BaseModel):
    customer_id: int
    customer_name: str
    segment_name: str
    urgency_level: str
    recommended_incentive: str
    recommended_channels: List[str]
    email_subject: str
    email_body: str
    sms_copy: str
    call_to_action: str
    quality_status: str
    quality_feedback: Optional[str]
    campaign_id: Optional[int] = None


# -----------------------------------------------------------------------------
# Endpoints
# -----------------------------------------------------------------------------
@app.get("/", tags=["System"])
def root():
    return {
        "service": "RetentionAI Backend Service",
        "status": "online",
        "docs_url": "/docs",
        "version": "1.0.0",
    }


@app.get("/api/v1/health", tags=["System"])
def health_check():
    """Verify system health, database readiness, and Ollama connectivity."""
    db_ready = os.path.exists(os.path.join("data", "customer_retention.db"))
    
    # Check Ollama connectivity
    ollama_ready = False
    try:
        import httpx
        r = httpx.get("http://127.0.0.1:11434/api/tags", timeout=2.0)
        if r.status_code == 200:
            ollama_ready = True
    except Exception:
        ollama_ready = False

    return {
        "api_status": "healthy",
        "database_connected": db_ready,
        "ollama_server_reachable": ollama_ready,
        "model_configured": "qwen2.5:3b",
    }


@app.get("/api/v1/kpis", tags=["Analytics"])
def get_kpis():
    """Fetch executive overview KPIs for the dashboard ribbon."""
    try:
        summary = get_kpi_summary()
        return summary
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to calculate KPI summary: {str(e)}",
        )


@app.get("/api/v1/customers", tags=["Customers"])
def list_customers(
    segment: Optional[str] = Query(None, description="Filter by segment name"),
    min_churn_risk: Optional[float] = Query(None, ge=0.0, le=1.0, description="Minimum churn probability"),
    search: Optional[str] = Query(None, description="Search by name or customer ID"),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    """Retrieve filtered, paginated customer list."""
    customers, total_count = get_customers(
        segment=segment,
        min_churn_risk=min_churn_risk,
        search=search,
        limit=limit,
        offset=offset,
    )
    return {
        "total_records": total_count,
        "limit": limit,
        "offset": offset,
        "customers": customers,
    }


@app.get("/api/v1/customers/{customer_id}", tags=["Customers"])
def get_customer(customer_id: int):
    """Fetch complete Customer 360 profile by ID."""
    cust = get_customer_by_id(customer_id)
    if not cust:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Customer #{customer_id} not found.",
        )
    return cust


@app.post("/api/v1/campaigns/generate", response_model=CampaignResponse, tags=["AI Agents"])
def generate_retention_campaign(req: CampaignGenerateRequest):
    """Invokes the LangGraph Multi-Agent workflow to generate a personalized

    retention package for a customer using local Ollama model.
    """
    cust = get_customer_by_id(req.customer_id)
    if not cust:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Customer #{req.customer_id} not found.",
        )

    # Format customer state payload
    customer_payload = {
        "id": int(cust["ID"]),
        "name": str(cust["Customer_Name"]),
        "age": int(cust["Age"]),
        "income": float(cust["Income"]),
        "marital_status": str(cust["Marital_Status_Clean"]),
        "children": int(cust["Total_Children"]),
        "segment_name": str(cust["Segment_Name"]),
        "rfm_score": float(cust["RFM_Weighted_Score"]),
        "recency_days": int(cust["Recency_Days"]),
        "total_purchases": int(cust["Frequency_Total_Purchases"]),
        "total_spend": float(cust["Monetary_Total_Spend"]),
        "churn_probability": float(cust["Churn_Probability"]),
        "predicted_ltv": float(cust["Predicted_LTV"]),
        "top_category": str(cust["Top_Category"]),
        "top_category_spend": float(cust["Top_Category_Spend"]),
    }

    initial_state = {
        "customer": customer_payload,
        "persona_summary": None,
        "urgency_level": None,
        "recommended_incentive": None,
        "recommended_channels": None,
        "email_subject": None,
        "email_body": None,
        "sms_copy": None,
        "call_to_action": None,
        "quality_status": None,
        "quality_feedback": None,
        "revision_count": 0,
    }

    try:
        # Execute LangGraph Multi-Agent StateGraph
        result = retention_agent_app.invoke(initial_state)

        # Log generated campaign to database
        campaign_record = {
            "customer_id": customer_payload["id"],
            "customer_name": customer_payload["name"],
            "segment_name": customer_payload["segment_name"],
            "urgency_level": result["urgency_level"],
            "incentive": result["recommended_incentive"],
            "channels": result["recommended_channels"],
            "email_subject": result["email_subject"],
            "email_body": result["email_body"],
            "sms_copy": result["sms_copy"],
            "call_to_action": result["call_to_action"],
            "quality_status": result["quality_status"],
        }
        campaign_id = log_campaign(campaign_record)

        return CampaignResponse(
            customer_id=customer_payload["id"],
            customer_name=customer_payload["name"],
            segment_name=customer_payload["segment_name"],
            urgency_level=result["urgency_level"],
            recommended_incentive=result["recommended_incentive"],
            recommended_channels=result["recommended_channels"],
            email_subject=result["email_subject"],
            email_body=result["email_body"],
            sms_copy=result["sms_copy"],
            call_to_action=result["call_to_action"],
            quality_status=result["quality_status"],
            quality_feedback=result.get("quality_feedback"),
            campaign_id=campaign_id,
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"LangGraph execution error: {str(e)}",
        )


@app.get("/api/v1/campaigns", tags=["AI Agents"])
def list_campaigns():
    """Retrieve history of generated retention campaigns."""
    from src.database import get_connection

    conn = get_connection()
    cursor = conn.cursor()
    rows = cursor.execute("SELECT * FROM campaigns ORDER BY campaign_id DESC LIMIT 50").fetchall()
    conn.close()
    return [dict(r) for r in rows]


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.app.main:app", host="127.0.0.1", port=8000, reload=True)

