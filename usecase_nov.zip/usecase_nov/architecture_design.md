# System Architecture: AI-Driven Customer Segmentation & Personalized Retention Platform

This document outlines the end-to-end architecture for building an AI-powered customer segmentation, predictive churn/LTV, and personalized campaign generation system utilizing **FastAPI**, **Streamlit**, **LangChain**, **LangGraph**, and local **Ollama** models.

---

## 1. High-Level System Architecture

```mermaid
graph TB
    subgraph UI["Presentation Layer (Streamlit)"]
        UI_Dash["Executive Dashboard<br/>(RFM & Cluster Distributions)"]
        UI_Customer["Customer 360 & Segment Explorer"]
        UI_Campaign["AI Campaign Studio<br/>(Personalized Copy & Offers)"]
        UI_Analytics["ML Model Diagnostics & Churn Matrix"]
    end

    subgraph API["Backend Service Layer (FastAPI)"]
        API_Gateway["FastAPI App Server (Uvicorn)"]
        
        subgraph Endpoints["API Endpoints"]
            EP_Data["/api/data<br/>Ingestion & Preprocessing"]
            EP_RFM["/api/segmentation<br/>RFM & Clustering (K-Means/DBSCAN)"]
            EP_Predict["/api/prediction<br/>Churn Risk & LTV (XGBoost/LightGBM)"]
            EP_GenAI["/api/campaigns<br/>LangGraph Agent Orchestration"]
        end
        
        subgraph CoreServices["Application Services"]
            Svc_ETL["Feature Engineering Service"]
            Svc_ML["ML Inference & Scoring Engine"]
            Svc_Agent["Agent Execution Service"]
        end
    end

    subgraph AgentLayer["Agentic Workflow Layer (LangGraph + LangChain)"]
        LG_Graph["LangGraph Retention Workflow StateGraph"]
        
        subgraph Nodes["Workflow Nodes"]
            Node_Profile["Profile & Segment Analyzer"]
            Node_Recommender["Product & Offer Recommender"]
            Node_Copywriter["Creative Copywriter Agent"]
            Node_Validator["Tone & Policy Validator"]
        end
    end

    subgraph LocalLLM["Local AI Inference (Ollama)"]
        Ollama_Engine["Ollama Runtime (e.g., Llama 3 / Mistral / Qwen)"]
        Ollama_Prompt["Personalized Marketing Prompts"]
    end

    subgraph Storage["Data & Model Storage"]
        DB_Data["Customer & Transaction Store (SQLite / Parquet / PostgreSQL)"]
        ML_Artifacts["Trained Models & Scalers (.pkl / .joblib / .json)"]
        Agent_Checkpoints["LangGraph Memory Checkpointer (MemorySaver / SQLite)"]
    end

    %% Interactions
    UI -->|REST / JSON| API_Gateway
    API_Gateway --> Endpoints
    EP_Data --> Svc_ETL
    EP_RFM --> Svc_ML
    EP_Predict --> Svc_ML
    EP_GenAI --> Svc_Agent

    Svc_ETL --> DB_Data
    Svc_ML --> ML_Artifacts
    Svc_ML --> DB_Data

    Svc_Agent --> LG_Graph
    LG_Graph --> Nodes
    Node_Copywriter -->|LangChain Ollama Wrapper| Ollama_Engine
    Node_Validator -->|LangChain Ollama Wrapper| Ollama_Engine
    LG_Graph --> Agent_Checkpoints
```

---

## 2. LangGraph Campaign Generation Workflow

The multi-agent workflow processes segment clusters, customer metrics, and churn indicators to produce personalized multi-channel retention strategies.

```mermaid
graph TD
    Start(["Input: Customer Profile + RFM Segment + Churn Score"]) --> Node_Analyze["1. Segment & Behavioral Analyzer Node"]
    
    Node_Analyze --> Node_Strategy["2. Retention Strategy & Offer Matcher Node"]
    
    Node_Strategy --> Node_Draft["3. Creative Copywriter Agent Node (Ollama LLM)"]
    
    Node_Draft --> Node_Review{"4. Policy & Tone Quality Gate"}
    
    Node_Review -- "Pass" --> End(["Final Campaign Payload: Email / SMS / Web In-App"])
    Node_Review -- "Needs Revision" --> Node_Draft
```

### State Graph Breakdown

| Node | Responsibility | Output Injected to State |
| :--- | :--- | :--- |
| **`SegmentAnalyzer`** | Consolidates RFM cluster, behavioral activity, and churn likelihood into a persona brief. | `customer_persona_summary`, `urgency_level` |
| **`OfferMatcher`** | Matches product affinity, discount budget, and incentive strategy based on churn/LTV tier. | `recommended_offer`, `target_channels` |
| **`CreativeCopywriter`** | Prompts Ollama local model via LangChain to generate personalized marketing copy across channels (email subject/body, push, SMS). | `draft_messages` |
| **`QualityGate`** | Validates generated copy against brand guidelines, clarity, and discount accuracy. Retries if defective. | `reviewed_campaign`, `status` |

---

## 3. End-to-End Execution Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Marketer as Marketing / Retention Specialist
    participant UI as Streamlit Web App
    participant API as FastAPI Backend
    participant ML as ML Engine (RFM + XGBoost)
    participant LG as LangGraph Workflow
    participant Ollama as Ollama Local LLM

    Marketer->>UI: 1. Uploads transactions / views segment dashboard
    UI->>API: GET /api/segmentation/summary
    API->>ML: Run RFM calculation & K-Means clustering
    ML-->>API: Clustered customer segments & metrics
    API-->>UI: Return segment distribution & customer list

    Marketer->>UI: 2. Selects at-risk segment or specific high-value customer
    UI->>API: POST /api/campaigns/generate (customerId / segmentId)
    API->>ML: Fetch customer feature vector & churn probability
    ML-->>API: Return Recency: 45d, Churn Risk: 0.78, Segment: "At-Risk High-Spender"

    API->>LG: Invoke Retention Agent Workflow(state)
    LG->>LG: Formulate persona brief & select win-back incentive
    LG->>Ollama: Prompt local LLM with persona + offer context
    Ollama-->>LG: Generated tailored email & SMS copy
    LG->>LG: Validate output tone and CTA
    LG-->>API: Return finalized campaign package
    API-->>UI: Deliver campaign preview, subject lines & CTA recommendations
    Marketer->>UI: 3. Approve and export/trigger campaign
```

---

## 4. Technology Stack & Component Responsibilities

| Layer | Technology | Primary Role |
| :--- | :--- | :--- |
| **Frontend / Dashboard** | `Streamlit` | Interactive user interface: RFM cluster visualization, customer lookup, churn probability radar, and AI campaign generator studio. |
| **Backend API** | `FastAPI` + `Pydantic` | High-performance async REST API providing endpoints for dataset ingestion, ML inference, and agent workflow triggers. |
| **Machine Learning** | `Scikit-Learn` + `XGBoost` | Unsupervised RFM behavioral clustering (K-Means / DBSCAN) and supervised predictive modeling (Churn probability & LTV estimation). |
| **Agentic Framework** | `LangGraph` + `LangChain` | Stateful, cyclical workflow management coordinating persona extraction, incentive matching, and copy generation. |
| **LLM Inference** | `Ollama` (`llama3`, `mistral`, or `qwen2.5`) | Local, privacy-preserving LLM inference for generating marketing copy, personalized subject lines, and multi-channel engagement strategies without external API costs. |
| **Persistence / Storage** | `SQLite` / `Parquet` + `Joblib` | Local data store for customer profile/transaction data and serialized ML model weights. |

---

## 5. Directory & Modular Project Structure

```text
poc_customer_segmentation/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI application entry point
│   │   ├── config.py            # Environment configurations (Ollama host, model name)
│   │   ├── api/
│   │   │   ├── routes_data.py   # Ingestion and synthetic data generation
│   │   │   ├── routes_ml.py     # RFM scoring, clustering & churn prediction
│   │   │   └── routes_agent.py  # LangGraph campaign generation endpoint
│   │   ├── ml/
│   │   │   ├── rfm_engine.py    # Recency, Frequency, Monetary calculations
│   │   │   ├── clustering.py    # K-Means / DBSCAN models
│   │   │   └── predictive.py    # Churn & LTV prediction (XGBoost)
│   │   ├── agents/
│   │   │   ├── state.py         # LangGraph state schema definition
│   │   │   ├── graph.py         # StateGraph build & compile
│   │   │   ├── nodes.py         # Agent execution nodes
│   │   │   └── prompts.py       # Prompt templates for Ollama
│   │   └── schemas/             # Pydantic request/response models
│   └── requirements.txt
├── frontend/
│   ├── app.py                   # Main Streamlit dashboard
│   ├── components/              # Charts, customer tables, campaign card components
│   └── requirements.txt
├── data/
│   └── sample_customers.csv     # Synthetic / demonstration customer & transaction dataset
├── models/                      # Saved trained models (.joblib)
└── usecase.txt                  # Problem statement & specifications
```
